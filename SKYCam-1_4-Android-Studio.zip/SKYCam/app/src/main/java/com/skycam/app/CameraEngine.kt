package com.skycam.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.provider.MediaStore
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.ZoomState
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.roundToInt
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Cau hinh khi gan camera.
 * sourceRatio: AspectRatio.RATIO_4_3 hoac RATIO_16_9 (khung hinh 1:1 lay tu 4:3 roi cat).
 * videoQuality: "uhd" (4K), "fhd" hoac "hd".
 */
class BindOptions(
    val front: Boolean,
    val video: Boolean,
    val highRes: Boolean,
    val sourceRatio: Int,
    val jpegQuality: Int,
    val videoQuality: String
)

/** Ket qua khi dat phoi sang thu cong cho che do Anh sang / Phao hoa. */
data class ManualExposure(val seconds: Float, val clamped: Boolean)

/**
 * Lop boc CameraX: mo camera, zoom, chup, quay, phoi sang dai (Camera2 interop).
 * Anh/video luu vao thu vien o thu muc DCIM/SKYCam.
 */
@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
class CameraEngine(private val context: Context) {

    private val mainExecutor = ContextCompat.getMainExecutor(context)
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var zoomLive: LiveData<ZoomState>? = null
    private var zoomObserver: Observer<ZoomState>? = null
    private var rotation: Int = android.view.Surface.ROTATION_0
    private var flashMode: Int = ImageCapture.FLASH_MODE_OFF
    private var isFront = false

    val isRecording: Boolean get() = recording != null

    // Phoi sang / ISO ma AE dang chon (cap nhat lien tuc tu khung xem truoc) - dung cho che do chup dem.
    @Volatile private var aeExposureNs: Long = 0L
    @Volatile private var aeIso: Int = 0

    suspend fun awaitProvider() {
        provider = suspendCancellableCoroutine<ProcessCameraProvider> { cont ->
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({ cont.resume(future.get()) }, mainExecutor)
        }
    }

    /**
     * Gan camera vao man hinh xem truoc. Che do anh: Preview + ImageCapture (4:3).
     * Che do video: Preview + VideoCapture (16:9, uu tien 4K).
     * Tra ve null neu thanh cong, nguoc lai tra ve thong bao loi.
     */
    fun bind(
        owner: LifecycleOwner,
        previewView: PreviewView,
        opt: BindOptions,
        startZoom: Float,
        onZoom: (min: Float, max: Float, current: Float) -> Unit
    ): String? {
        val p = provider ?: return "Camera chưa sẵn sàng"
        val front = opt.front
        val video = opt.video
        isFront = front
        zoomObserver?.let { zoomLive?.removeObserver(it) }

        val ratio = ratioStrategy(opt.sourceRatio)
        val previewSelector = ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build()
        val previewBuilder = Preview.Builder().setResolutionSelector(previewSelector)
        Camera2Interop.Extender(previewBuilder).setSessionCaptureCallback(
            object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: android.hardware.camera2.CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { aeExposureNs = it }
                    result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { aeIso = it }
                }
            }
        )
        val preview = previewBuilder.build()
        preview.setSurfaceProvider(previewView.surfaceProvider)
        val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA

        fun attempt(hr: Boolean): Camera {
            p.unbindAll()
            val useCase: UseCase = if (video) buildVideo(opt) else buildImage(opt, hr)
            return p.bindToLifecycle(owner, selector, preview, useCase)
        }

        val cam = try {
            attempt(opt.highRes && !video && !front)
        } catch (e: Exception) {
            try {
                attempt(false)
            } catch (e2: Exception) {
                return "Không mở được camera: ${e2.localizedMessage}"
            }
        }
        camera = cam

        val live = cam.cameraInfo.zoomState
        val observer = Observer<ZoomState> { onZoom(it.minZoomRatio, it.maxZoomRatio, it.zoomRatio) }
        live.observe(owner, observer)
        zoomLive = live
        zoomObserver = observer

        if (!front && startZoom != 1f) {
            val z = live.value
            val target = if (z != null) startZoom.coerceIn(z.minZoomRatio, z.maxZoomRatio) else startZoom
            cam.cameraControl.setZoomRatio(target)
        }
        return null
    }

    private fun ratioStrategy(sourceRatio: Int): AspectRatioStrategy =
        if (sourceRatio == AspectRatio.RATIO_16_9) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY

    private fun buildImage(opt: BindOptions, highRes: Boolean): ImageCapture {
        val builder = ResolutionSelector.Builder().setAspectRatioStrategy(ratioStrategy(opt.sourceRatio))
        if (highRes) {
            builder.setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
        }
        val capture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setJpegQuality(opt.jpegQuality.coerceIn(1, 100))
            .setResolutionSelector(builder.build())
            .setFlashMode(flashMode)
            .setTargetRotation(rotation)
            .build()
        imageCapture = capture
        videoCapture = null
        return capture
    }

    private fun buildVideo(opt: BindOptions): VideoCapture<Recorder> {
        val order = when (opt.videoQuality) {
            "hd" -> listOf(Quality.HD, Quality.SD)
            "fhd" -> listOf(Quality.FHD, Quality.HD)
            else -> listOf(Quality.UHD, Quality.FHD, Quality.HD)
        }
        val recorder = Recorder.Builder()
            .setAspectRatio(opt.sourceRatio)
            .setQualitySelector(
                QualitySelector.fromOrderedList(order, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
            )
            .build()
        val capture = VideoCapture.Builder(recorder).setTargetRotation(rotation).build()
        videoCapture = capture
        imageCapture = null
        return capture
    }

    // ---------- Dieu khien ----------

    fun setZoom(ratio: Float) {
        camera?.cameraControl?.setZoomRatio(ratio)
    }

    fun setFlash(mode: Int) {
        flashMode = mode
        imageCapture?.flashMode = mode
    }

    fun setRotation(surfaceRotation: Int) {
        rotation = surfaceRotation
        imageCapture?.targetRotation = surfaceRotation
        videoCapture?.targetRotation = surfaceRotation
    }

    fun hasFlashUnit(): Boolean = camera?.cameraInfo?.hasFlashUnit() ?: false

    /** Den pin lien tuc (che do "Luon bat" khi chup, "Bat" khi quay video). */
    fun setTorch(on: Boolean) {
        if (hasFlashUnit()) camera?.cameraControl?.enableTorch(on)
    }

    /** Khoang bu sang (chi so nho nhat, lon nhat, buoc EV moi chi so). */
    fun evRange(): Triple<Int, Int, Float> {
        val state = camera?.cameraInfo?.exposureState ?: return Triple(0, 0, 0f)
        if (!state.isExposureCompensationSupported) return Triple(0, 0, 0f)
        val r = state.exposureCompensationRange
        return Triple(r.lower, r.upper, state.exposureCompensationStep.toFloat())
    }

    fun setEv(index: Int) {
        camera?.cameraControl?.setExposureCompensationIndex(index)
    }

    fun focusAt(previewView: PreviewView, x: Float, y: Float) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        cam.cameraControl.startFocusAndMetering(action)
    }

    // ---------- Chup anh ----------

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun takePhoto(onResult: (Uri?, String?) -> Unit) {
        val capture = imageCapture
        if (capture == null) {
            onResult(null, "Camera chưa sẵn sàng")
            return
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "SKYCam_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/SKYCam")
        }
        val meta = ImageCapture.Metadata().apply { isReversedHorizontal = isFront }
        val options = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).setMetadata(meta).build()
        capture.takePicture(options, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                onResult(output.savedUri, null)
            }

            override fun onError(exception: ImageCaptureException) {
                onResult(null, "Không lưu được ảnh: ${exception.message}")
            }
        })
    }

    suspend fun takePhotoSuspend(): Pair<Uri?, String?> =
        suspendCancellableCoroutine { cont ->
            takePhoto { uri, err -> if (cont.isActive) cont.resume(Pair(uri, err)) }
        }

    // ---------- Phoi sang dai (Anh sang / Phao hoa) ----------

    private class Limits(val minNs: Long, val maxNs: Long, val isoMin: Int, val isoMax: Int)

    private fun readLimits(): Limits? {
        val cam = camera ?: return null
        val info = Camera2CameraInfo.from(cam.cameraInfo)
        val expRange = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
            ?: return null
        val isoRange = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val maxFrame = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_MAX_FRAME_DURATION)
        var maxNs: Long = expRange.upper
        if (maxFrame != null && maxFrame < maxNs) maxNs = maxFrame
        if (maxNs < 500_000_000L) return null
        return Limits(
            expRange.lower, maxNs,
            isoRange?.lower ?: 50, isoRange?.upper ?: 6400
        )
    }

    private fun pushOptions(expNs: Long, iso: Int, focusInfinity: Boolean) {
        val cam = camera ?: return
        val builder = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            .setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs)
            .setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
            .setCaptureRequestOption(CaptureRequest.SENSOR_FRAME_DURATION, expNs)
            .setCaptureRequestOption(
                CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY
            )
        if (focusInfinity) {
            builder
                .setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                .setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, 0f)
        }
        Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(builder.build())
    }

    /**
     * Anh sang / Phao hoa: tat tu dong phoi sang, dat thoi gian phoi sang + ISO thu cong, lay net vo cuc.
     * Tra ve null neu may khong cho ung dung thu ba chinh phoi sang dai (duoi 0,5 giay).
     */
    fun applyManualExposure(seconds: Float, iso: Int, focusInfinity: Boolean = true): ManualExposure? {
        val lim = readLimits() ?: return null
        val wantedNs = (seconds * 1_000_000_000.0).toLong()
        val clamped = wantedNs > lim.maxNs
        val expNs = wantedNs.coerceIn(lim.minNs, lim.maxNs)
        pushOptions(expNs, iso.coerceIn(lim.isoMin, lim.isoMax), focusInfinity)
        return ManualExposure(expNs / 1_000_000_000f, clamped)
    }

    /**
     * Chup dem: lay "luong sang" ma AE dang chon (phoi sang x ISO), keo dai thoi gian phoi sang
     * len [seconds] giay (0 = tu dong 1-5 giay) va ha ISO tuong ung de anh van dung sang, it nhieu hon.
     * Giu lay net tu dong. Neu canh qua sang thi tu rut ngan phoi sang de khong bi chay sang.
     */
    fun applyNightExposure(seconds: Float): ManualExposure? {
        val lim = readLimits() ?: return null
        val ae = aeExposureNs
        val aeIsoNow = aeIso
        if (ae <= 0L || aeIsoNow <= 0) return null
        val budget = ae.toDouble() * aeIsoNow           // ns x ISO, khong doi khi doi phoi sang
        val wantedNs: Long = if (seconds <= 0f) {
            (budget / 200.0).toLong().coerceIn(1_000_000_000L, 5_000_000_000L)
        } else {
            (seconds * 1_000_000_000.0).toLong()
        }
        val clamped = wantedNs > lim.maxNs
        var expNs = wantedNs.coerceIn(lim.minNs, lim.maxNs)
        var isoValue = (budget / expNs).roundToInt()
        if (isoValue < lim.isoMin) {
            // Canh sang: ISO thap nhat van qua sang -> rut ngan thoi gian phoi sang.
            isoValue = lim.isoMin
            expNs = (budget / lim.isoMin).toLong().coerceIn(lim.minNs, expNs)
        }
        isoValue = isoValue.coerceIn(lim.isoMin, lim.isoMax)
        pushOptions(expNs, isoValue, focusInfinity = false)
        return ManualExposure(expNs / 1_000_000_000f, clamped)
    }

    fun clearManualExposure() {
        val cam = camera ?: return
        Camera2CameraControl.from(cam.cameraControl).clearCaptureRequestOptions()
    }

    // ---------- Quay video ----------

    @SuppressLint("MissingPermission")
    fun startRecording(
        withAudio: Boolean,
        onSeconds: (Long) -> Unit,
        onFinish: (Uri?, String?) -> Unit
    ): Boolean {
        val capture = videoCapture ?: return false
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "SKYCam_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/SKYCam")
        }
        val options = MediaStoreOutputOptions.Builder(
            context.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending = capture.output.prepareRecording(context, options)
        if (withAudio) pending = pending.withAudioEnabled()
        recording = pending.start(mainExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Status ->
                    onSeconds(event.recordingStats.recordedDurationNanos / 1_000_000_000L)
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    if (event.hasError()) onFinish(null, "Lỗi khi quay video (mã ${event.error})")
                    else onFinish(event.outputResults.outputUri, null)
                }
                else -> {}
            }
        }
        return true
    }

    fun stopRecording() {
        recording?.stop()
    }

    fun release() {
        recording?.stop()
        recording = null
        provider?.unbindAll()
    }
}
