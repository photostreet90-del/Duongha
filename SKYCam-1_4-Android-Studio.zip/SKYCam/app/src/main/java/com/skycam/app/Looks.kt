package com.skycam.app

import android.graphics.ColorMatrix

/**
 * Bo loc mau mo phong phong cach phim / may anh cua Fuji, Leica, Nikon (khong phai san pham chinh thuc cua cac hang).
 * Moi bo loc gom ma tran mau 4x5 (ColorMatrix), do toi goc (vignette) va hat phim (grain).
 */
class Look(
    val id: String,
    val brand: String,          // "" (goc), "Fuji", "Leica", "Nikon"
    val label: String,
    val matrix: FloatArray,
    val vignette: Float = 0f,
    val grain: Float = 0f
)

object Looks {

    private fun identity(): FloatArray = ColorMatrix().array.copyOf()

    /**
     * Xay ma tran: bao hoa -> can bang kenh mau -> tuong phan -> lech mau (nang/ha tung kenh) -> phai mau (nang den).
     * rOff/gOff/bOff la do lech cong them (thang 0-255) de tao sac bong toi / vung sang.
     */
    private fun grade(
        sat: Float,
        contrast: Float,
        bright: Float = 0f,
        r: Float = 1f,
        g: Float = 1f,
        b: Float = 1f,
        rOff: Float = 0f,
        gOff: Float = 0f,
        bOff: Float = 0f,
        fade: Float = 0f
    ): FloatArray {
        val m = ColorMatrix()
        m.setSaturation(sat)
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    r, 0f, 0f, 0f, 0f,
                    0f, g, 0f, 0f, 0f,
                    0f, 0f, b, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        val t = (-0.5f * contrast + 0.5f) * 255f + bright
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    contrast, 0f, 0f, 0f, t + rOff,
                    0f, contrast, 0f, 0f, t + gOff,
                    0f, 0f, contrast, 0f, t + bOff,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        if (fade > 0f) {
            val s = 1f - fade
            val o = fade * 40f
            m.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        s, 0f, 0f, 0f, o,
                        0f, s, 0f, 0f, o,
                        0f, 0f, s, 0f, o,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        return m.array.copyOf()
    }

    val NONE = Look("none", "", "Gốc", identity())

    val BRANDS = listOf("Fuji", "Leica", "Nikon")

    val all: List<Look> = listOf(
        NONE,

        // ===== Phong cach phim Fuji (8) =====
        Look("fuji_provia", "Fuji", "Provia", grade(sat = 1.06f, contrast = 1.06f, b = 1.01f)),
        Look("fuji_velvia", "Fuji", "Velvia", grade(sat = 1.38f, contrast = 1.16f, bright = -3f, r = 1.03f), vignette = 0.12f),
        Look("fuji_astia", "Fuji", "Astia", grade(sat = 1.0f, contrast = 0.95f, r = 1.02f, g = 1.01f, fade = 0.03f)),
        Look("fuji_classic_chrome", "Fuji", "Classic Chrome", grade(sat = 0.74f, contrast = 1.12f, b = 0.95f, fade = 0.04f), vignette = 0.10f, grain = 0.04f),
        Look("fuji_classic_neg", "Fuji", "Classic Neg", grade(sat = 0.95f, contrast = 1.22f, r = 1.03f, g = 0.98f, rOff = 2f, gOff = -2f, bOff = 5f, fade = 0.03f), vignette = 0.10f, grain = 0.05f),
        Look("fuji_nostalgic_neg", "Fuji", "Nostalgic Neg", grade(sat = 0.92f, contrast = 1.05f, r = 1.06f, b = 0.90f, rOff = 6f, gOff = 2f, fade = 0.05f), grain = 0.05f),
        Look("fuji_eterna", "Fuji", "Eterna", grade(sat = 0.80f, contrast = 0.90f, r = 0.98f, b = 1.02f, fade = 0.06f), grain = 0.03f),
        Look("fuji_acros", "Fuji", "Acros", grade(sat = 0f, contrast = 1.20f, b = 0.97f), vignette = 0.08f, grain = 0.08f),

        // ===== Phong cach Leica (6) =====
        Look("leica_natural", "Leica", "Natural", grade(sat = 0.92f, contrast = 1.10f, bright = -4f, r = 1.02f, b = 0.97f), vignette = 0.20f),
        Look("leica_vibrant", "Leica", "Vibrant", grade(sat = 1.20f, contrast = 1.18f, bright = -3f, r = 1.02f, b = 0.98f), vignette = 0.22f),
        Look("leica_warm", "Leica", "Warm", grade(sat = 0.95f, contrast = 1.10f, bright = -3f, r = 1.06f, g = 1.01f, b = 0.92f), vignette = 0.20f),
        Look("leica_cool", "Leica", "Cool Street", grade(sat = 0.85f, contrast = 1.15f, bright = -5f, r = 0.96f, b = 1.06f), vignette = 0.22f, grain = 0.03f),
        Look("leica_bw", "Leica", "B&W", grade(sat = 0f, contrast = 1.30f, bright = -6f), vignette = 0.15f, grain = 0.10f),
        Look("leica_bw_hc", "Leica", "B&W Hi-Con", grade(sat = 0f, contrast = 1.55f, bright = -14f), vignette = 0.20f, grain = 0.12f),

        // ===== Phong cach Picture Control cua Nikon (6) =====
        Look("nikon_standard", "Nikon", "Standard", grade(sat = 1.05f, contrast = 1.04f)),
        Look("nikon_vivid", "Nikon", "Vivid", grade(sat = 1.30f, contrast = 1.12f)),
        Look("nikon_portrait", "Nikon", "Portrait", grade(sat = 0.95f, contrast = 0.96f, r = 1.03f, b = 0.98f, fade = 0.02f)),
        Look("nikon_landscape", "Nikon", "Landscape", grade(sat = 1.22f, contrast = 1.10f, g = 1.03f, b = 1.04f)),
        Look("nikon_mono", "Nikon", "Monochrome", grade(sat = 0f, contrast = 1.12f)),
        Look("nikon_flat", "Nikon", "Flat", grade(sat = 0.85f, contrast = 0.82f, fade = 0.08f))
    )

    fun byId(id: String): Look = all.firstOrNull { it.id == id } ?: NONE
    fun ofBrand(brand: String): List<Look> = all.filter { it.brand == brand }
}
