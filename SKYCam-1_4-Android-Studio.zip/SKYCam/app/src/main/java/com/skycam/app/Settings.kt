package com.skycam.app

import android.content.SharedPreferences
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Mot gia tri cai dat: doc/ghi qua State cua Compose va tu luu vao SharedPreferences. */
class PrefDelegate<T>(
    private val state: MutableState<T>,
    private val write: (T) -> Unit
) : ReadWriteProperty<Any?, T> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): T = state.value
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        state.value = value
        write(value)
    }
}

/** Toan bo cai dat cua camera, luu ben vung giua cac lan mo ung dung. */
class CamSettings(private val prefs: SharedPreferences) {

    private fun pref(key: String, def: Int) =
        PrefDelegate(mutableStateOf(prefs.getInt(key, def))) { prefs.edit().putInt(key, it).apply() }

    private fun pref(key: String, def: String) =
        PrefDelegate(mutableStateOf(prefs.getString(key, def) ?: def)) { prefs.edit().putString(key, it).apply() }

    private fun pref(key: String, def: Boolean) =
        PrefDelegate(mutableStateOf(prefs.getBoolean(key, def))) { prefs.edit().putBoolean(key, it).apply() }

    // Anh
    var quality by pref("quality", 95)                 // 100 / 95 / 85 / 70
    var format by pref("format", "jpeg")               // jpeg | png | webp
    var highRes by pref("highres", false)
    var photoRatio by pref("photo_ratio", "4:3")       // 4:3 | 16:9 | 1:1
    // Video
    var videoRatio by pref("video_ratio", "16:9")      // 16:9 | 4:3
    var videoQuality by pref("video_quality", "uhd")   // uhd | fhd | hd
    // Chung
    var grid by pref("grid", false)
    var sound by pref("sound", true)
    // Bo loc, dau chim
    var lookId by pref("look", "none")
    var wmStyle by pref("wm_style", 0)                 // 0 tat, 1 dau chim, 2 khung
    var wmText by pref("wm_text", "SKY Cam")
    var wmInfo by pref("wm_info", true)
}

private val Accent = Color(0xFFFF8A1F)
private val Panel = Color(0xFF1C1C1E)

@Composable
fun SettingsScreen(cfg: CamSettings, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Column(
        Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(40.dp).background(Panel, CircleShape).clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Close, contentDescription = "Đóng", tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.size(14.dp))
            Text("Cài đặt camera", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Section("Ảnh") {
                Label("Chất lượng ảnh")
                Chips(
                    listOf("Cao nhất" to "100", "Cao" to "95", "Chuẩn" to "85", "Tiết kiệm" to "70"),
                    cfg.quality.toString()
                ) { cfg.quality = it.toInt() }
                Hint("Áp dụng cho ảnh JPEG và WebP. Cao nhất cho dung lượng lớn nhất.")

                Label("Định dạng ảnh")
                Chips(
                    listOf("JPEG" to "jpeg", "PNG" to "png", "WebP" to "webp"),
                    cfg.format
                ) { cfg.format = it }
                Hint("PNG và WebP được chuyển đổi từ ảnh gốc sau khi chụp (PNG không nén mất chi tiết nhưng rất nặng).")

                ToggleRow("Độ phân giải cao (HR)", cfg.highRes) { cfg.highRes = it }
                Hint("Chụp ở độ phân giải sensor cao hơn nếu máy cho phép; ảnh chụp có thể chậm hơn.")
            }

            Section("Video") {
                Label("Chất lượng video")
                Chips(
                    listOf("Tối đa (4K)" to "uhd", "Full HD" to "fhd", "HD" to "hd"),
                    cfg.videoQuality
                ) { cfg.videoQuality = it }
                Hint("Nếu máy không hỗ trợ mức đã chọn, app tự hạ xuống mức gần nhất.")
            }

            Section("Chung") {
                ToggleRow("Lưới 3×3", cfg.grid) { cfg.grid = it }
                ToggleRow("Âm thanh chụp / quay", cfg.sound) { cfg.sound = it }
            }

            Section("Giới thiệu") {
                Hint(
                    "Bộ lọc màu Fuji, Leica, Nikon là các bộ lọc mô phỏng phong cách phim và máy ảnh, " +
                        "không phải sản phẩm chính thức của các hãng. Bộ lọc, dấu chìm và định dạng PNG/WebP " +
                        "áp dụng cho ảnh; video quay ở dạng gốc."
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, color = Accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun Label(text: String) {
    Text(text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Color(0x99FFFFFF), fontSize = 12.sp, lineHeight = 17.sp)
}

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, value) ->
            val on = value == selected
            Text(
                label,
                color = if (on) Color.Black else Color.White,
                fontSize = 13.sp,
                fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                modifier = Modifier
                    .background(if (on) Accent else Color(0xFF2C2C2E), RoundedCornerShape(50))
                    .clickable { onSelect(value) }
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            )
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Accent,
                uncheckedThumbColor = Color(0xFFCCCCCC),
                uncheckedTrackColor = Color(0xFF3A3A3C)
            )
        )
    }
}
