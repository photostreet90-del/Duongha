package com.skycam.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.util.Random
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Hau ky anh vua chup: ap bo loc mau film, do toi goc, hat phim, dau chim / khung thong so.
 * Ghi de len chinh file anh trong thu vien (giu lai cac thong so EXIF chinh).
 */
object PhotoProcessor {

    class WatermarkSpec(val style: Int, val text: String, val showInfo: Boolean) // style: 0 tat, 1 dau chim, 2 khung

    private val KEEP_TAGS = listOf(
        ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL,
        ExifInterface.TAG_DATETIME, ExifInterface.TAG_DATETIME_ORIGINAL,
        ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_F_NUMBER,
        ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY,
        ExifInterface.TAG_FOCAL_LENGTH, ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM,
        ExifInterface.TAG_EXPOSURE_BIAS_VALUE, ExifInterface.TAG_FLASH
    )

    /**
     * Hau ky anh. Tra ve Uri cua anh sau xu ly (giu nguyen neu van la JPEG; la Uri moi neu doi sang PNG/WebP),
     * hoac null neu that bai (anh goc van con nguyen).
     * format: "jpeg" | "png" | "webp"; quality: 1-100 (dung cho JPEG va WebP); cropSquare: cat vuong 1:1 o giua.
     */
    fun process(
        context: Context,
        uri: Uri,
        look: Look,
        wm: WatermarkSpec,
        cropSquare: Boolean,
        format: String,
        quality: Int
    ): Uri? {
        return try {
            val resolver = context.contentResolver

            // 1) Doc EXIF
            var orientation = ExifInterface.ORIENTATION_NORMAL
            val tags = HashMap<String, String>()
            resolver.openInputStream(uri)?.use { input ->
                val ex = ExifInterface(input)
                orientation = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                for (t in KEEP_TAGS) ex.getAttribute(t)?.let { v -> tags[t] = v }
            }

            // 2) Giai ma anh (thu nho neu qua lon de tiet kiem bo nho)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 4400) sample *= 2
            val decoded = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return null
            var src = upright(decoded, orientation)
            if (cropSquare) {
                val side = minOf(src.width, src.height)
                val cropped = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
                if (cropped !== src) src.recycle()
                src = cropped
            }

            val w = src.width
            val h = src.height
            val frameH = if (wm.style == 2) (h * 0.075f).roundToInt() else 0
            val out = Bitmap.createBitmap(w, h + frameH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            if (frameH > 0) canvas.drawColor(Color.WHITE)

            // 3) Bo loc mau
            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            if (look.id != "none") paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(look.matrix))
            canvas.drawBitmap(src, 0f, 0f, paint)
            src.recycle()

            // 4) Do toi goc + hat phim (chi tren vung anh)
            if (look.vignette > 0f) drawVignette(canvas, w, h, look.vignette)
            if (look.grain > 0f) drawGrain(canvas, w, h, look.grain)

            // 5) Dau chim / khung
            if (wm.style != 0) drawWatermark(canvas, w, h, frameH, wm, tags)

            // 6) Nen anh vao bo nho truoc (de khong lam hong anh goc neu loi)
            val bytes = ByteArrayOutputStream()
            val q = quality.coerceIn(1, 100)
            when (format) {
                "png" -> out.compress(Bitmap.CompressFormat.PNG, 100, bytes)
                "webp" -> {
                    @Suppress("DEPRECATION")
                    val fmt = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                    out.compress(fmt, q, bytes)
                }
                else -> out.compress(Bitmap.CompressFormat.JPEG, q, bytes)
            }
            out.recycle()

            if (format == "png" || format == "webp") {
                // Doi dinh dang: tao muc moi trong thu vien roi xoa file JPEG goc
                var baseName = "SKYCam_" + System.currentTimeMillis()
                resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrEmpty()) baseName = n.substringBeforeLast('.')
                    }
                }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, baseName + if (format == "png") ".png" else ".webp")
                    put(MediaStore.MediaColumns.MIME_TYPE, if (format == "png") "image/png" else "image/webp")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/SKYCam")
                }
                val newUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
                val ok = resolver.openOutputStream(newUri)?.use { it.write(bytes.toByteArray()); true } ?: false
                if (!ok) {
                    resolver.delete(newUri, null, null)
                    return null
                }
                resolver.delete(uri, null, null)
                return newUri
            }

            // JPEG: ghi de len file cu va tra lai EXIF (anh da xoay dung chieu nen huong = binh thuong)
            resolver.openOutputStream(uri, "wt")?.use { it.write(bytes.toByteArray()) } ?: return null
            try {
                resolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                    val ex = ExifInterface(pfd.fileDescriptor)
                    for ((k, v) in tags) ex.setAttribute(k, v)
                    ex.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
                    ex.saveAttributes()
                }
            } catch (_: Exception) {
            }
            uri
        } catch (_: Throwable) {
            null
        }
    }

    private fun upright(bmp: Bitmap, orientation: Int): Bitmap {
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
        }
        if (m.isIdentity) return bmp
        val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (rotated !== bmp) bmp.recycle()
        return rotated
    }

    private fun drawVignette(canvas: Canvas, w: Int, h: Int, strength: Float) {
        val radius = hypot(w / 2.0, h / 2.0).toFloat()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = RadialGradient(
            w / 2f, h / 2f, radius,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb((strength * 255).roundToInt().coerceIn(0, 255), 0, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
    }

    private fun drawGrain(canvas: Canvas, w: Int, h: Int, strength: Float) {
        val size = 256
        val rnd = Random(7)
        val px = IntArray(size * size) {
            val g = (128 + rnd.nextGaussian() * 42).roundToInt().coerceIn(0, 255)
            Color.rgb(g, g, g)
        }
        val tile = Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
        val paint = Paint()
        paint.shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
        paint.alpha = (strength * 255 * 3).roundToInt().coerceIn(0, 255)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        tile.recycle()
    }

    private fun formatExposure(raw: String?): String {
        val d = raw?.toDoubleOrNull() ?: return ""
        if (d <= 0.0) return ""
        return if (d >= 1.0) "${d.roundToInt()}s" else "1/${(1.0 / d).roundToInt()}s"
    }

    private fun infoLine(tags: Map<String, String>): String {
        val parts = ArrayList<String>()
        tags[ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM]?.let { parts.add("${it}mm") }
        tags[ExifInterface.TAG_F_NUMBER]?.toDoubleOrNull()?.let { parts.add("f/" + "%.1f".format(it)) }
        formatExposure(tags[ExifInterface.TAG_EXPOSURE_TIME]).takeIf { it.isNotEmpty() }?.let { parts.add(it) }
        tags[ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY]?.let { parts.add("ISO $it") }
        return parts.joinToString("  ")
    }

    private fun dateLine(tags: Map<String, String>): String {
        val raw = tags[ExifInterface.TAG_DATETIME_ORIGINAL] ?: tags[ExifInterface.TAG_DATETIME] ?: return ""
        if (raw.length < 16) return ""
        return raw.substring(0, 10).replace(':', '.') + " " + raw.substring(11, 16)
    }

    private fun drawWatermark(
        canvas: Canvas, w: Int, h: Int, frameH: Int, wm: WatermarkSpec, tags: Map<String, String>
    ) {
        val name = wm.text.trim()
        val info = if (wm.showInfo) infoLine(tags) else ""
        val date = if (wm.showInfo) dateLine(tags) else ""
        if (wm.style == 1) {
            // Dau chim: chu trang ban trong suot o goc duoi ben phai
            val margin = w * 0.03f
            val big = w * 0.034f
            val small = w * 0.022f
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(215, 255, 255, 255)
                textAlign = Paint.Align.RIGHT
                setShadowLayer(w * 0.003f, 0f, w * 0.0015f, Color.argb(150, 0, 0, 0))
            }
            var y = h - margin
            val second = listOf(info, date).filter { it.isNotEmpty() }.joinToString("  ·  ")
            if (second.isNotEmpty()) {
                p.textSize = small
                p.typeface = Typeface.DEFAULT
                canvas.drawText(second, w - margin, y, p)
                y -= small * 1.5f
            }
            if (name.isNotEmpty()) {
                p.textSize = big
                p.typeface = Typeface.DEFAULT_BOLD
                canvas.drawText(name, w - margin, y, p)
            }
        } else {
            // Khung: thanh trang ben duoi, ten ben trai, thong so ben phai
            val top = h.toFloat()
            val pad = w * 0.03f
            val nameP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(25, 25, 25)
                typeface = Typeface.DEFAULT_BOLD
                textSize = frameH * 0.36f
            }
            val infoP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(95, 95, 95)
                textAlign = Paint.Align.RIGHT
                textSize = frameH * 0.26f
            }
            val cy = top + frameH / 2f
            if (name.isNotEmpty()) canvas.drawText(name, pad, cy + nameP.textSize * 0.35f, nameP)
            if (info.isNotEmpty() || date.isNotEmpty()) {
                if (info.isNotEmpty() && date.isNotEmpty()) {
                    canvas.drawText(info, w - pad, cy - frameH * 0.04f, infoP)
                    canvas.drawText(date, w - pad, cy + frameH * 0.30f, infoP)
                } else {
                    canvas.drawText(info.ifEmpty { date }, w - pad, cy + infoP.textSize * 0.35f, infoP)
                }
            }
        }
    }
}
