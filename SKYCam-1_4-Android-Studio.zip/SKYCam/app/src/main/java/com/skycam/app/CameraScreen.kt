package com.skycam.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.media.MediaActionSound
import android.net.Uri
import android.view.OrientationEventListener
import android.view.View
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.AspectRatio
import androidx.camera.core.ImageCapture
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrandingWatermark
import androidx.compose.material.icons.filled.FilterVintage
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

enum class CamMode(val label: String) {
    VIDEO("Video"),
    PHOTO("Ảnh"),
    LIGHT("Ánh sáng"),
    FIREWORKS("Pháo hoa")
}

enum class FlashChoice { OFF, ON, AUTO, TORCH }

private val ZOOM_PRESETS = listOf(1f, 2f, 3.5f, 7f)
private val Accent = Color(0xFFFF8A1F)
private val Glass = Color(0x66000000)
private val GlassLight = Color(0x33FFFFFF)

@Composable
fun CamRoot() {
    val context = LocalContext.current
    fun granted(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED
    var hasCamera by remember { mutableStateOf(granted(Manifest.permission.CAMERA)) }
    var hasAudio by remember { mutableStateOf(granted(Manifest.permission.RECORD_AUDIO)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasCamera = granted(Manifest.permission.CAMERA)
        hasAudio = granted(Manifest.permission.RECORD_AUDIO)
    }
    LaunchedEffect(Unit) {
        if (!hasCamera) launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }
    if (hasCamera) {
        CameraScreen(hasAudio = hasAudio)
    } else {
        Column(
            Modifier.fillMaxSize().background(Color.Black).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("SKY Cam cần quyền Camera để hoạt động", color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Button(onClick = {
                launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
            }) { Text("Cấp quyền") }
        }
    }
}

@Composable
fun CameraScreen(hasAudio: Boolean) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val cfg = remember { CamSettings(context.getSharedPreferences("skycam_prefs", Context.MODE_PRIVATE)) }
    val engine = remember { CameraEngine(context) }
    val processLock = remember { Mutex() }
    val sound = remember {
        MediaActionSound().also {
            it.load(MediaActionSound.SHUTTER_CLICK)
            it.load(MediaActionSound.START_VIDEO_RECORDING)
            it.load(MediaActionSound.STOP_VIDEO_RECORDING)
        }
    }
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    var ready by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(CamMode.PHOTO) }
    var front by remember { mutableStateOf(false) }
    var flashChoice by remember { mutableStateOf(FlashChoice.OFF) }
    var showFlashBar by remember { mutableStateOf(false) }
    var hasFlash by remember { mutableStateOf(false) }
    var night by remember { mutableStateOf(false) }
    var nightSec by remember { mutableStateOf(0) }          // 0 = tu dong
    var evIndex by remember { mutableStateOf(0) }
    var evMin by remember { mutableStateOf(0) }
    var evMax by remember { mutableStateOf(0) }
    var evStep by remember { mutableStateOf(0f) }
    var showEv by remember { mutableStateOf(false) }
    var zoom by remember { mutableStateOf(1f) }
    var minZoom by remember { mutableStateOf(1f) }
    var maxZoom by remember { mutableStateOf(1f) }
    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var lastIsVideo by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var recSeconds by remember { mutableStateOf(0L) }
    var busy by remember { mutableStateOf(false) }
    var remain by remember { mutableStateOf(0) }
    var lightSec by remember { mutableStateOf(8) }
    var fireSec by remember { mutableStateOf(4) }
    var focusPoint by remember { mutableStateOf<Offset?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var zoomJob by remember { mutableStateOf<Job?>(null) }
    var showFilters by remember { mutableStateOf(false) }
    var lookBrand by remember { mutableStateOf(Looks.byId(cfg.lookId).brand) }
    var showWm by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(0) }
    var thumbVersion by remember { mutableStateOf(0) }

    val isVideo = mode == CamMode.VIDEO
    val isLongMode = mode == CamMode.LIGHT || mode == CamMode.FIREWORKS
    val isPhotoOrVideo = mode == CamMode.PHOTO || mode == CamMode.VIDEO
    val nightOn = night && mode == CamMode.PHOTO && !front
    val look = Looks.byId(cfg.lookId)
    // Che do video chi co Tat / Bat (den pin); che do anh co du 4 lua chon.
    val effectiveFlash = if (isVideo && flashChoice != FlashChoice.TORCH) FlashChoice.OFF else flashChoice
    val evText = if (evIndex == 0) "0.0" else "%+.1f".format(evIndex * evStep)

    // Ti le khung hinh: anh 4:3 / 16:9 / 1:1, video 16:9 / 4:3 (1:1 lay tu 4:3 roi cat vuong o giua)
    val ratioStr = if (isVideo) cfg.videoRatio else cfg.photoRatio
    val sourceRatio = if (ratioStr == "16:9") AspectRatio.RATIO_16_9 else AspectRatio.RATIO_4_3
    val previewAspect = when (ratioStr) {
        "16:9" -> 9f / 16f
        "1:1" -> 1f
        else -> 3f / 4f
    }
    // Anh can hau ky khi: co bo loc, dau chim, cat 1:1 hoac doi dinh dang
    val needsProcess = look.id != "none" || cfg.wmStyle != 0 || cfg.photoRatio == "1:1" || cfg.format != "jpeg"
    val captureQuality = if (needsProcess) 100 else cfg.quality

    fun playSound(kind: Int) {
        if (cfg.sound) sound.play(kind)
    }

    LaunchedEffect(Unit) {
        engine.awaitProvider()
        ready = true
    }
    LaunchedEffect(ready, isVideo, front, cfg.highRes, sourceRatio, captureQuality, cfg.videoQuality) {
        if (!ready) return@LaunchedEffect
        val opt = BindOptions(front, isVideo, cfg.highRes, sourceRatio, captureQuality, cfg.videoQuality)
        val err = engine.bind(owner, previewView, opt, if (front) 1f else zoom) { mn, mx, z ->
            minZoom = mn
            maxZoom = mx
            zoom = z
        }
        if (err != null) message = err
        hasFlash = engine.hasFlashUnit()
        val ev = engine.evRange()
        evMin = ev.first
        evMax = ev.second
        evStep = ev.third
        engine.setEv(evIndex.coerceIn(evMin, evMax))
        engine.setTorch(flashChoice == FlashChoice.TORCH && isPhotoOrVideo && !front)
    }
    // Flash khi chup: Bat / Tu dong; "Luon bat" va video dung den pin.
    LaunchedEffect(flashChoice, nightOn, ready) {
        engine.setFlash(
            if (nightOn) ImageCapture.FLASH_MODE_OFF else when (flashChoice) {
                FlashChoice.ON -> ImageCapture.FLASH_MODE_ON
                FlashChoice.AUTO -> ImageCapture.FLASH_MODE_AUTO
                else -> ImageCapture.FLASH_MODE_OFF
            }
        )
    }
    LaunchedEffect(flashChoice, mode, front, ready) {
        if (ready) engine.setTorch(flashChoice == FlashChoice.TORCH && isPhotoOrVideo && !front)
    }
    // Xem truoc bo loc mau ngay tren khung ngam (video quay o dang goc nen khong ap bo loc)
    LaunchedEffect(look.id, mode) {
        if (look.id != "none" && mode != CamMode.VIDEO) {
            val paint = android.graphics.Paint().apply {
                colorFilter = ColorMatrixColorFilter(ColorMatrix(look.matrix))
            }
            previewView.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
        } else {
            previewView.setLayerType(View.LAYER_TYPE_NONE, null)
        }
    }
    LaunchedEffect(message) {
        message?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            message = null
        }
    }
    DisposableEffect(Unit) {
        val listener = object : OrientationEventListener(context) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                val r = when (orientation) {
                    in 45..134 -> android.view.Surface.ROTATION_270
                    in 135..224 -> android.view.Surface.ROTATION_180
                    in 225..314 -> android.view.Surface.ROTATION_90
                    else -> android.view.Surface.ROTATION_0
                }
                engine.setRotation(r)
            }
        }
        listener.enable()
        onDispose {
            listener.disable()
            engine.release()
            sound.release()
        }
    }

    fun goZoom(target: Float) {
        val t = target.coerceIn(minZoom, maxZoom)
        zoomJob?.cancel()
        zoomJob = scope.launch {
            animate(zoom, t, animationSpec = tween(260)) { v, _ -> engine.setZoom(v) }
        }
    }

    fun nextRatio() {
        if (isVideo) {
            cfg.videoRatio = if (cfg.videoRatio == "16:9") "4:3" else "16:9"
        } else {
            cfg.photoRatio = when (cfg.photoRatio) {
                "4:3" -> "16:9"
                "16:9" -> "1:1"
                else -> "4:3"
            }
        }
    }

    // Luu xong: neu can thi hau ky (bo loc, dau chim, cat 1:1, doi dinh dang) roi cap nhat anh thu nho
    fun saved(uri: Uri?, video: Boolean, error: String?) {
        if (uri == null) {
            message = error ?: "Không lưu được"
            return
        }
        lastUri = uri
        lastIsVideo = video
        if (video || !needsProcess) return
        val spec = PhotoProcessor.WatermarkSpec(cfg.wmStyle, cfg.wmText, cfg.wmInfo)
        val chosen = look
        val square = cfg.photoRatio == "1:1"
        val fmt = cfg.format
        val q = cfg.quality
        processing++
        scope.launch {
            val result = processLock.withLock {
                withContext(Dispatchers.Default) {
                    PhotoProcessor.process(context, uri, chosen, spec, square, fmt, q)
                }
            }
            processing--
            if (result != null) {
                lastUri = result
                thumbVersion++
            } else {
                message = "Không áp dụng được bộ lọc / định dạng cho ảnh này, giữ ảnh gốc"
            }
        }
    }

    fun runLongExposure(nightShot: Boolean) {
        scope.launch {
            busy = true
            val applied = if (nightShot) {
                engine.applyNightExposure(nightSec.toFloat())
            } else {
                val wanted = if (mode == CamMode.LIGHT) lightSec else fireSec
                engine.applyManualExposure(wanted.toFloat(), 100)
            }
            if (applied == null) {
                busy = false
                if (nightShot) {
                    message = "Máy chưa cho chụp đêm thủ công, đã chụp thường"
                    playSound(MediaActionSound.SHUTTER_CLICK)
                    engine.takePhoto { uri, err -> saved(uri, false, err) }
                } else {
                    message = "Máy không cho ứng dụng thứ ba phơi sáng thủ công trên 0,5 giây"
                }
                return@launch
            }
            if (applied.clamped) message = "Máy chỉ hỗ trợ tối đa ${applied.seconds.roundToInt()} giây"
            delay(600)
            playSound(MediaActionSound.SHUTTER_CLICK)
            val total = ceil(applied.seconds).toInt()
            remain = total
            val ticker = launch {
                for (i in total downTo 1) {
                    remain = i
                    delay(1000)
                }
            }
            val result = engine.takePhotoSuspend()
            ticker.cancel()
            engine.clearManualExposure()
            remain = 0
            busy = false
            saved(result.first, false, result.second)
        }
    }

    fun onShutter() {
        if (busy) return
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        when (mode) {
            CamMode.PHOTO -> {
                if (nightOn) {
                    runLongExposure(true)
                } else {
                    playSound(MediaActionSound.SHUTTER_CLICK)
                    engine.takePhoto { uri, err -> saved(uri, false, err) }
                }
            }
            CamMode.VIDEO -> {
                if (recording) {
                    engine.stopRecording()
                } else {
                    val ok = engine.startRecording(
                        withAudio = hasAudio,
                        onSeconds = { recSeconds = it },
                        onFinish = { uri, err ->
                            recording = false
                            recSeconds = 0
                            playSound(MediaActionSound.STOP_VIDEO_RECORDING)
                            saved(uri, true, err)
                        }
                    )
                    if (ok) {
                        recording = true
                        recSeconds = 0
                        playSound(MediaActionSound.START_VIDEO_RECORDING)
                    }
                }
            }
            CamMode.LIGHT, CamMode.FIREWORKS -> runLongExposure(false)
        }
    }

    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // ---------- Khung xem truoc ----------
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .aspectRatio(previewAspect)
                .clip(RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp))
        ) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

            // Luoi 3x3
            if (cfg.grid) {
                Canvas(Modifier.fillMaxSize()) {
                    val line = Color(0x66FFFFFF)
                    for (i in 1..2) {
                        drawLine(line, Offset(size.width * i / 3f, 0f), Offset(size.width * i / 3f, size.height), strokeWidth = 1.5f)
                        drawLine(line, Offset(0f, size.height * i / 3f), Offset(size.width, size.height * i / 3f), strokeWidth = 1.5f)
                    }
                }
            }

            // Cham de lay net, hai ngon tay de zoom
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            showFlashBar = false
                            showEv = false
                            showFilters = false
                            if (!busy) {
                                focusPoint = offset
                                engine.focusAt(previewView, offset.x, offset.y)
                            }
                        }
                    }
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoomChange, _ ->
                            if (!busy && !front && zoomChange != 1f) {
                                zoomJob?.cancel()
                                engine.setZoom((zoom * zoomChange).coerceIn(minZoom, maxZoom))
                            }
                        }
                    }
            )

            focusPoint?.let { FocusRing(it) { focusPoint = null } }

            // Xem truoc dau chim
            if (!isVideo && cfg.wmStyle != 0) {
                val label = cfg.wmText.trim()
                if (cfg.wmStyle == 1) {
                    Text(
                        label, color = Color(0xD9FFFFFF), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp)
                    )
                } else {
                    Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(30.dp)
                            .background(Color.White).padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(label, color = Color(0xFF191919), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Thanh bu sang (EV)
            if (showEv && evMax > evMin && isPhotoOrVideo) {
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = topInset + 60.dp, start = 20.dp, end = 20.dp)
                        .fillMaxWidth()
                        .background(Glass, RoundedCornerShape(50))
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("EV", color = Color(0xB3FFFFFF), fontSize = 12.sp)
                    Slider(
                        value = evIndex.toFloat(),
                        onValueChange = { v ->
                            evIndex = v.roundToInt().coerceIn(evMin, evMax)
                            engine.setEv(evIndex)
                        },
                        valueRange = evMin.toFloat()..evMax.toFloat(),
                        steps = (evMax - evMin - 1).coerceAtLeast(0),
                        colors = SliderDefaults.colors(
                            thumbColor = Accent,
                            activeTrackColor = Accent,
                            inactiveTrackColor = Color(0x55FFFFFF),
                            activeTickColor = Color.Transparent,
                            inactiveTickColor = Color.Transparent
                        ),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )
                    Text(
                        evText, color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            evIndex = 0
                            engine.setEv(0)
                        }
                    )
                }
            }

            // Cac dieu khien phu nam de len khung ngam, sat day (kieu iOS 18)
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = if (!isVideo && cfg.wmStyle == 2) 42.dp else 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
            // Chon bo loc: hang hang (Fuji / Leica / Nikon), roi cac bo loc cua hang do
            if (showFilters && !isVideo) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val tabs = listOf("" to "Gốc") + Looks.BRANDS.map { it to it }
                    tabs.forEach { (brand, label) ->
                        val on = if (brand.isEmpty()) cfg.lookId == "none" && lookBrand.isEmpty() else lookBrand == brand
                        Text(
                            label,
                            color = if (on) Color.Black else Color.White,
                            fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(if (on) Accent else Glass, RoundedCornerShape(50))
                                .clickable {
                                    lookBrand = brand
                                    if (brand.isEmpty()) cfg.lookId = "none"
                                }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        )
                    }
                }
                if (lookBrand.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Looks.ofBrand(lookBrand).forEach { l ->
                            val on = cfg.lookId == l.id
                            Text(
                                l.label,
                                color = if (on) Accent else Color.White,
                                fontSize = 13.sp,
                                fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier
                                    .background(GlassLight, RoundedCornerShape(50))
                                    .border(1.dp, if (on) Accent else Color.Transparent, RoundedCornerShape(50))
                                    .clickable { cfg.lookId = l.id }
                                    .padding(horizontal = 14.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            // Chup dem: nhan cam hien thoi gian phoi sang, cham de doi (Tu dong / 1s / 3s / 5s)
            if (nightOn) {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, bottom = 8.dp)) {
                    NightPill(if (nightSec == 0) "Tự động" else "${nightSec}s") {
                        if (!busy) nightSec = when (nightSec) { 0 -> 1; 1 -> 3; 3 -> 5; else -> 0 }
                    }
                }
            }

            if (isLongMode) {
                val options = if (mode == CamMode.LIGHT) listOf(4, 8, 15) else listOf(2, 4, 6)
                val selected = if (mode == CamMode.LIGHT) lightSec else fireSec
                Text(
                    if (mode == CamMode.LIGHT) "Vệt sáng · đặt máy cố định hoặc dùng chân máy"
                    else "Pháo hoa · đặt máy cố định, ngắm xa",
                    color = Color(0xB3FFFFFF), fontSize = 12.sp
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { s ->
                        Text(
                            "${s}s",
                            color = if (s == selected) Color.Black else Color.White,
                            fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .background(if (s == selected) Accent else Glass, RoundedCornerShape(50))
                                .clickable(enabled = !busy) {
                                    if (mode == CamMode.LIGHT) lightSec = s else fireSec = s
                                }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            // Hang zoom: dau chim (trai) | chip zoom (giua) | bo loc (phai)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isVideo) {
                    GlassIcon(Icons.Default.BrandingWatermark, "Dấu chìm", Modifier,
                        tint = if (cfg.wmStyle != 0) Accent else Color.White) { showWm = true }
                } else {
                    Spacer(Modifier.size(40.dp))
                }
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    if (!front) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val onPreset by remember { derivedStateOf { ZOOM_PRESETS.any { abs(zoom - it) < 0.05f } } }
                            if (!onPreset) {
                                Text(
                                    "%.1fx".format(zoom), color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                            }
                            ZoomPill(zoom, minZoom, maxZoom, enabled = !busy) { goZoom(it) }
                        }
                    }
                }
                if (!isVideo) {
                    GlassIcon(Icons.Default.FilterVintage, "Bộ lọc màu", Modifier,
                        tint = if (look.id != "none") Accent else Color.White) {
                        showFilters = !showFilters
                        showEv = false
                        showFlashBar = false
                    }
                } else {
                    Spacer(Modifier.size(40.dp))
                }
            }
            Spacer(Modifier.height(10.dp))

            }

            // Dem nguoc khi phoi sang dai
            if (busy) {
                Column(
                    Modifier.fillMaxSize().background(Color(0x77000000)),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("$remain", color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light)
                    Text("giây · giữ máy thật yên", color = Color(0xCCFFFFFF), fontSize = 14.sp)
                }
            }
        }

        // ---------- Thanh tren (de len khung ngam) ----------
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(topInset + 84.dp)
                .background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent)))
        )
        Box(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().height(52.dp)
                .padding(horizontal = 16.dp)
        ) {
            run {
                TopPill(
                    modifier = Modifier.align(Alignment.CenterStart),
                    flashAvailable = isPhotoOrVideo && hasFlash && !front,
                    isVideo = isVideo,
                    choice = effectiveFlash,
                    expanded = showFlashBar,
                    showNight = mode == CamMode.PHOTO && !front,
                    night = nightOn,
                    evText = evText,
                    evAvailable = isPhotoOrVideo && evMax > evMin,
                    ratioText = ratioStr,
                    ratioEnabled = !busy && !recording,
                    onRatio = { nextRatio() },
                    onFlashIcon = { showFlashBar = !showFlashBar; showEv = false },
                    onPick = { c -> flashChoice = c; showFlashBar = false },
                    onNight = { night = !night },
                    onEv = { showEv = !showEv; showFlashBar = false }
                )
            }
            if (!showFlashBar) {
                if (recording) {
                    Row(
                        Modifier.align(Alignment.CenterEnd).background(Glass, RoundedCornerShape(50))
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(9.dp).background(Color(0xFFFF3B30), CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "%02d:%02d".format(recSeconds / 60, recSeconds % 60),
                            color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium
                        )
                    }
                } else {
                    Row(
                        Modifier.align(Alignment.CenterEnd),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (mode == CamMode.PHOTO && !front) {
                            Text(
                                "HR",
                                color = if (cfg.highRes) Color.Black else Color.White,
                                fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .background(if (cfg.highRes) Accent else Glass, RoundedCornerShape(50))
                                    .clickable {
                                        cfg.highRes = !cfg.highRes
                                        message = if (cfg.highRes) "Ảnh độ phân giải cao: bật (chụp có thể chậm hơn)"
                                        else "Ảnh độ phân giải cao: tắt"
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                        GlassIcon(Icons.Default.Settings, "Cài đặt", Modifier, size = 38) {
                            if (!busy) showSettings = true
                        }
                    }
                }
            }
        }

        // ---------- Dieu khien phia duoi ----------
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    if (isVideo) Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000)))
                    else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                )
                .navigationBarsPadding()
                .padding(bottom = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CamMode.values().forEach { m ->
                    Text(
                        m.label,
                        color = if (m == mode) Color.White else Color(0xB3FFFFFF),
                        fontSize = 14.sp,
                        fontWeight = if (m == mode) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier
                            .background(if (m == mode) GlassLight else Color.Transparent, RoundedCornerShape(50))
                            .clickable(enabled = !recording && !busy) {
                                mode = m
                                showFlashBar = false
                                showEv = false
                            }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }
            Spacer(Modifier.height(14.dp))

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 32.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Thumb(lastUri, lastIsVideo, thumbVersion, processing > 0)
                Shutter(mode, recording, busy) { onShutter() }
                GlassIcon(Icons.Default.FlipCameraAndroid, "Đổi camera", Modifier, size = 52) {
                    if (!recording && !busy) {
                        front = !front
                        zoom = 1f
                    }
                }
            }
        }

        // ---------- Hop thoai dau chim ----------
        if (showWm) {
            AlertDialog(
                onDismissRequest = { showWm = false },
                confirmButton = { TextButton(onClick = { showWm = false }) { Text("Xong") } },
                title = { Text("Dấu chìm") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Tắt" to 0, "Dấu chìm" to 1, "Khung" to 2).forEach { (label, value) ->
                                val on = cfg.wmStyle == value
                                Text(
                                    label,
                                    color = if (on) Color.Black else Color(0xFF333333),
                                    fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                                    modifier = Modifier
                                        .background(if (on) Accent else Color(0xFFE8E8E8), RoundedCornerShape(50))
                                        .clickable { cfg.wmStyle = value }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                        OutlinedTextField(
                            value = cfg.wmText,
                            onValueChange = { cfg.wmText = it.take(40) },
                            label = { Text("Nội dung") },
                            singleLine = true
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Hiện thông số chụp", modifier = Modifier.weight(1f))
                            Switch(checked = cfg.wmInfo, onCheckedChange = { cfg.wmInfo = it })
                        }
                        Text(
                            "Dấu chìm: chữ trắng mờ ở góc dưới phải. Khung: thanh trắng bên dưới ảnh (kiểu máy film). " +
                                "Chỉ áp dụng cho ảnh.",
                            fontSize = 12.sp, color = Color(0xFF666666)
                        )
                    }
                }
            )
        }

        // ---------- Man hinh cai dat ----------
        if (showSettings) {
            SettingsScreen(cfg = cfg, onClose = { showSettings = false })
        }
    }
}

@Composable
private fun TopPill(
    modifier: Modifier,
    flashAvailable: Boolean,
    isVideo: Boolean,
    choice: FlashChoice,
    expanded: Boolean,
    showNight: Boolean,
    night: Boolean,
    evText: String,
    evAvailable: Boolean,
    onFlashIcon: () -> Unit,
    onPick: (FlashChoice) -> Unit,
    onNight: () -> Unit,
    onEv: () -> Unit,
    ratioText: String,
    ratioEnabled: Boolean,
    onRatio: () -> Unit
) {
    val flashIcon = when (choice) {
        FlashChoice.OFF -> Icons.Default.FlashOff
        FlashChoice.ON -> Icons.Default.FlashOn
        FlashChoice.AUTO -> Icons.Default.FlashAuto
        FlashChoice.TORCH -> Icons.Default.FlashlightOn
    }
    val options: List<Pair<String, FlashChoice>> =
        if (isVideo) listOf("Tắt" to FlashChoice.OFF, "Bật" to FlashChoice.TORCH)
        else listOf(
            "Tắt" to FlashChoice.OFF, "Bật" to FlashChoice.ON,
            "Tự động" to FlashChoice.AUTO, "Luôn bật" to FlashChoice.TORCH
        )
    Row(
        modifier.background(Glass, RoundedCornerShape(50)).padding(horizontal = 4.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (flashAvailable) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onFlashIcon),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    flashIcon, contentDescription = "Đèn flash",
                    tint = if (choice == FlashChoice.OFF) Color.White else Accent,
                    modifier = Modifier.size(21.dp)
                )
            }
        }
        if (expanded && flashAvailable) {
            Text("Đèn flash", color = Color(0x99FFFFFF), fontSize = 12.sp, modifier = Modifier.padding(start = 2.dp, end = 4.dp))
            options.forEach { (label, value) ->
                Text(
                    label,
                    color = if (value == choice) Accent else Color.White,
                    fontSize = 14.sp,
                    fontWeight = if (value == choice) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier.clickable { onPick(value) }.padding(horizontal = 9.dp, vertical = 8.dp)
                )
            }
        } else {
            if (showNight) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onNight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.NightsStay, contentDescription = "Chụp đêm",
                        tint = if (night) Accent else Color.White, modifier = Modifier.size(21.dp)
                    )
                }
            }
            if (evAvailable) {
                Text(
                    "EV $evText",
                    color = if (evText == "0.0") Color.White else Accent,
                    fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable(onClick = onEv).padding(horizontal = 10.dp, vertical = 8.dp)
                )
            }
            // Ti le khung hinh nam ngay ben canh EV (cham de doi)
            Text(
                ratioText,
                color = if (ratioEnabled) Color.White else Color(0x66FFFFFF),
                fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable(enabled = ratioEnabled, onClick = onRatio)
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
private fun NightPill(label: String, onClick: () -> Unit) {
    Row(
        Modifier.background(Accent, RoundedCornerShape(50)).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.NightsStay, null, tint = Color.Black, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ZoomPill(zoom: Float, minZoom: Float, maxZoom: Float, enabled: Boolean, onPick: (Float) -> Unit) {
    Row(
        Modifier.background(Glass, RoundedCornerShape(50)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ZOOM_PRESETS.forEach { z ->
            val supported = z >= minZoom - 0.01f && z <= maxZoom + 0.01f
            val selected = abs(zoom - z) < 0.05f
            val label = if (z % 1f == 0f) "${z.toInt()}x" else "${z}x"
            Box(
                Modifier
                    .size(width = 46.dp, height = 36.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (selected) GlassLight else Color.Transparent)
                    .clickable(enabled = enabled && supported) { onPick(z) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = when {
                        selected -> Accent
                        supported -> Color.White
                        else -> Color(0x55FFFFFF)
                    },
                    fontSize = if (selected) 15.sp else 13.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun GlassIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    modifier: Modifier,
    size: Int = 40,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier.size(size.dp).background(Glass, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size((size * 0.52f).dp))
    }
}

@Composable
private fun Shutter(mode: CamMode, recording: Boolean, busy: Boolean, onClick: () -> Unit) {
    val inner by animateDpAsState(if (recording) 24.dp else 50.dp, label = "shutter")
    val ring = if (mode == CamMode.LIGHT || mode == CamMode.FIREWORKS) Accent else Color.White
    Box(
        Modifier
            .size(64.dp)
            .border(3.dp, ring, CircleShape)
            .clickable(
                enabled = !busy,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(inner).background(
                if (mode == CamMode.VIDEO) Color(0xFFFF3B30) else Color.White,
                if (recording) RoundedCornerShape(8.dp) else CircleShape
            )
        )
    }
}

@Composable
private fun Thumb(uri: Uri?, isVideo: Boolean, version: Int, processing: Boolean) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(initialValue = null, uri, version) {
        value = if (uri == null) null else withContext(Dispatchers.IO) {
            try {
                context.contentResolver.loadThumbnail(uri, android.util.Size(256, 256), null).asImageBitmap()
            } catch (_: Exception) {
                null
            }
        }
    }
    Box(
        Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(GlassLight)
            .clickable(enabled = uri != null) {
                val intent = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, if (isVideo) "video/*" else "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                try {
                    context.startActivity(intent)
                } catch (_: Exception) {
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val bmp = bitmap
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = "Ảnh vừa chụp", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            if (isVideo) Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        if (processing) {
            Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
                Text("···", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun FocusRing(center: Offset, onDone: () -> Unit) {
    val radius = with(LocalDensity.current) { 34.dp.toPx() }
    LaunchedEffect(center) {
        delay(900)
        onDone()
    }
    Box(
        Modifier
            .offset { IntOffset((center.x - radius).roundToInt(), (center.y - radius).roundToInt()) }
            .size(68.dp)
            .border(2.dp, Accent, CircleShape)
    )
}
